import 'dart:ui';

class Colors{

  static const Color primaryColor = Color(0xFF031E4B);



}